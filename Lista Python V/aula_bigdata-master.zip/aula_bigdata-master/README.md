# aula_bigdata
Baixar o pacote aula_bigdata para a VM e descompactar o arquivo
Abrir o terminal e entrar no diretorio mapreduce_wordcount

hadoop fs -mkdir /fiap

hadoop fs -mkdir /fiap/input

hadoop fs -put hadoop.txt /fiap/input 

hadoop fs -cat /fiap/input/hadoop.txt

hadoop jar wordcount.jar WordCount /fiap/input /fiap/output

hadoop fs -ls /fiap/output

hadoop fs -cat /fiap/output/part-r-00000 | more
