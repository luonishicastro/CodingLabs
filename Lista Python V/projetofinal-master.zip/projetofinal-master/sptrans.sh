/usr/bin/python3.4 /home/cloudera/sptrans.py
