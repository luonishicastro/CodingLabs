from .ProcessamentoBasico import *
from .FeatureDerivative import *
from .FeatureStandard import *